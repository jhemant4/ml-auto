/**
 * MedicalTracker.jsx  —  v4 (exact column names fixed)
 * NBFC Home Loan Insurance — Medical Checkup Tracker Dashboard
 *
 * npm install recharts xlsx
 *
 * v4 fixes:
 *  • COL_MAP updated with exact headers from the real Excel file:
 *      "tpa app no", "policy#", "testcategory", "sumassured", "age",
 *      "appointment data", "ageing", "date (disposition date)", etc.
 *  • findHeaderRow threshold lowered to 2 (was 4) — won't skip the real header row
 *  • Fuzzy matching tightened so short keys like "age" don't collide
 */

import { useState, useMemo, useCallback, useRef } from "react";
import * as XLSX from "xlsx";
import {
  PieChart, Pie, Cell, BarChart, Bar,
  XAxis, YAxis, Tooltip, ResponsiveContainer, Legend,
} from "recharts";

/* ─── Column name map (keys = lowercase+trimmed Excel header) ─────────── */
const COL_MAP = {
  // DATE
  "date"                          : "date",

  // TPA APPLICATION NUMBER
  "tpa app no"                    : "tpaApplicationNo",
  "tpa app number"                : "tpaApplicationNo",
  "tpa application no"            : "tpaApplicationNo",
  "tpa application number"        : "tpaApplicationNo",
  "tpaapplicationnumber"          : "tpaApplicationNo",
  "tpaapplicationno"              : "tpaApplicationNo",

  // LOAN NUMBER
  "loan no"                       : "loanNumber",
  "loan number"                   : "loanNumber",
  "loannumber"                    : "loanNumber",

  // POLICY
  "policy#"                       : "policy",
  "policy"                        : "policy",
  "policy no"                     : "policy",
  "policy no."                    : "policy",
  "policy number"                 : "policy",

  // NAME OF LIFE ASSURED
  "name of the life assured"      : "nameOfLifeAssured",
  "name of life assured"          : "nameOfLifeAssured",
  "life assured name"             : "nameOfLifeAssured",
  "assured name"                  : "nameOfLifeAssured",

  // TEST CATEGORY
  "testcategory"                  : "testCategory",
  "test category"                 : "testCategory",
  "test categories"               : "testCategory",
  "tests"                         : "testCategory",

  // PREMIUM
  "premium"                       : "premium",

  // SUM ASSURED
  "sumassured"                    : "sumAssured",
  "sum assured"                   : "sumAssured",

  // AGE — exact only (short key, no fuzzy)
  "age"                           : "age",

  // PRODUCT TYPE
  "product type"                  : "productType",
  "producttype"                   : "productType",

  // MEDICAL TYPE
  "medical type"                  : "medicalType",
  "medicaltype"                   : "medicalType",
  "med type"                      : "medicalType",

  // TPA NAME
  "tpa name"                      : "tpaName",
  "tpaname"                       : "tpaName",

  // GENDER
  "gender"                        : "gender",

  // SUB STATUS
  "sub status"                    : "substatus",
  "substatus"                     : "substatus",
  "sub-status"                    : "substatus",

  // APPOINTMENT DATE  ← your Excel says "appointment data"
  "appointment date"              : "appointmentDate",
  "appointment data"              : "appointmentDate",   // ← exact match from your file
  "appt date"                     : "appointmentDate",
  "appt. date"                    : "appointmentDate",
  "appointmentdate"               : "appointmentDate",

  // FINAL STATUS
  "final status"                  : "finalStatus",
  "finalstatus"                   : "finalStatus",

  // AGING / AGEING
  "aging"                         : "aging",
  "ageing"                        : "aging",

  // BRANCH
  "branch"                        : "branch",

  // CUSTOMER CONTACT
  "customer contact no"           : "customerContact",
  "customer contact number"       : "customerContact",
  "customer contact"              : "customerContact",
  "contact number"                : "customerContact",
  "contact no"                    : "customerContact",

  // ZONE
  "zone"                          : "zone",

  // STATE
  "state"                         : "state",

  // GEO
  "geo"                           : "geo",

  // DISPOSITION
  "disposition"                   : "disposition",

  // DISPOSITION DATE — separate field so it doesn't collide with "date"
  "date (disposition date)"       : "dispositionDate",
  "disposition date"              : "dispositionDate",
  "dispositiondate"               : "dispositionDate",
  "timestamp"                     : "timestamp",
};

// Fields that should be coerced to Number
const NUMERIC_FIELDS = new Set(["premium", "sumAssured", "aging", "age"]);

// Keys that are too short for fuzzy matching — exact only
const EXACT_ONLY_KEYS = new Set(["age", "geo", "date", "zone", "state", "branch", "gender", "premium", "policy", "tests"]);

function cleanHeader(raw) {
  return String(raw)
    .replace(/^\uFEFF/, "")   // strip BOM
    .toLowerCase()
    .trim();
}

function mapHeader(raw) {
  const key = cleanHeader(raw);
  if (!key) return null;

  // 1. Exact match (always try first)
  if (COL_MAP[key] !== undefined) return COL_MAP[key];

  // 2. Fuzzy only for longer keys that won't cause collisions
  if (!EXACT_ONLY_KEYS.has(key)) {
    for (const [pattern, field] of Object.entries(COL_MAP)) {
      if (EXACT_ONLY_KEYS.has(pattern)) continue;   // skip short patterns in fuzzy pass
      if (pattern.length >= 8 && key.includes(pattern)) return field;
      if (pattern.length >= 8 && pattern.includes(key)) return field;
    }
  }
  return null;
}

// Find the first row with ≥2 recognisable column headers (lowered from 4)
function findHeaderRow(rows) {
  for (let i = 0; i < Math.min(rows.length, 10); i++) {
    const matched = rows[i].filter(cell => mapHeader(cell) !== null).length;
    if (matched >= 2) return i;
  }
  return 0;
}

/* Normalise finalStatus to known buckets */
function normaliseFinalStatus(raw) {
  if (!raw) return "";
  const s = String(raw).toLowerCase().trim();
  if (s.includes("complet")) return "completed";
  if (
    s.includes("not contact") || s.includes("non contact") ||
    s.includes("not reachable") || s.includes("not answer") ||
    s.includes("no response") || s.includes("not respond") ||
    s.includes("contactable")
  ) return "non contactable";
  if (s.includes("reschedul")) return "rescheduled";
  if (s.includes("pending") || s.includes("schedul") || s.includes("process")) return "pending";
  return s;
}

function parseExcel(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const wb = XLSX.read(e.target.result, { type: "array", cellDates: true });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json(ws, { header: 1, defval: "" });

        if (rows.length < 2) return resolve({ data: [], debug: { headerRow: 0, mappedHeaders: [] } });

        const headerRowIdx = findHeaderRow(rows);
        const rawHeaders   = rows[headerRowIdx];
        const headers      = rawHeaders.map(mapHeader);

        const mappedHeaders = rawHeaders.map((h, i) => ({
          raw: String(h),
          mapped: headers[i] || "— unmapped —",
          ok: !!headers[i],
        }));

        const data = rows.slice(headerRowIdx + 1)
          .filter(row => row.some(cell => cell !== "" && cell !== null && cell !== undefined))
          .map(row => {
            const obj = {};
            headers.forEach((key, i) => {
              if (!key) return;
              let val = row[i];
              if (NUMERIC_FIELDS.has(key)) {
                val = parseFloat(String(val).replace(/,/g, "")) || 0;
              }
              if (val instanceof Date) {
                val = val.toLocaleDateString("en-IN", { day: "2-digit", month: "2-digit", year: "2-digit" });
              }
              obj[key] = (val === null || val === undefined) ? "" : val;
            });
            if (obj.finalStatus !== undefined) {
              obj.finalStatus = normaliseFinalStatus(obj.finalStatus);
            }
            return obj;
          });

        resolve({ data, debug: { headerRow: headerRowIdx, mappedHeaders } });
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = reject;
    reader.readAsArrayBuffer(file);
  });
}

/* ─── Palette ─────────────────────────────────────────────────────────── */
const STATUS_COLOR = {
  "completed"       : { bg: "#eaf8f0", color: "#1a6b42", dot: "#27a06b" },
  "pending"         : { bg: "#fef5e4", color: "#7d4e05", dot: "#d4870f" },
  "non contactable" : { bg: "#fdecea", color: "#7a1f1f", dot: "#c0392b" },
  "rescheduled"     : { bg: "#e8f2fc", color: "#0d3f73", dot: "#2471b8" },
};
const DISP_COLORS  = ["#27a06b","#2471b8","#c0392b","#d4870f","#7c5cbf","#e07b39","#666"];
const AGING_COLORS = ["#27a06b","#4aab7a","#d4870f","#c0392b","#7a1f1f"];

const agingColor = (d) => d >= 60 ? "#c0392b" : d >= 30 ? "#d4870f" : "#27a06b";
const fmt = (n) => {
  if (!n || isNaN(n)) return "—";
  return n >= 100000 ? `₹${(n / 100000).toFixed(1)}L` : `₹${(n / 1000).toFixed(0)}K`;
};

/* ─── Small components ───────────────────────────────────────────────── */
function Badge({ value }) {
  const s = STATUS_COLOR[String(value).toLowerCase()] || { bg: "#f0f0f0", color: "#555" };
  return (
    <span style={{
      display: "inline-block", padding: "2px 10px", borderRadius: 20,
      fontSize: 11, fontWeight: 600, background: s.bg, color: s.color, whiteSpace: "nowrap",
    }}>
      {value || "—"}
    </span>
  );
}

function MetricCard({ label, value, sub, color }) {
  return (
    <div style={{ background: "#f7f8fa", borderRadius: 10, padding: "14px 18px", minWidth: 0 }}>
      <div style={{ fontSize: 11, color: "#888", textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: 6 }}>{label}</div>
      <div style={{ fontSize: 26, fontWeight: 700, color: color || "#1a1a2e", lineHeight: 1 }}>{value}</div>
      {sub && <div style={{ fontSize: 11, color: "#aaa", marginTop: 4 }}>{sub}</div>}
    </div>
  );
}

function Card({ title, children, style }) {
  return (
    <div style={{ background: "#fff", border: "1px solid #eee", borderRadius: 12, padding: "18px 20px", ...style }}>
      {title && <div style={{ fontSize: 13, fontWeight: 600, color: "#555", marginBottom: 14 }}>{title}</div>}
      {children}
    </div>
  );
}

const ChartTip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background: "#fff", border: "1px solid #e0e0e0", borderRadius: 8, padding: "8px 14px", fontSize: 12 }}>
      <div style={{ fontWeight: 600, marginBottom: 2 }}>{payload[0].payload?.fullName || label || payload[0].name}</div>
      <div style={{ color: payload[0].fill || "#333" }}>{payload[0].value} cases</div>
    </div>
  );
};

/* ─── Debug Panel ─────────────────────────────────────────────────────── */
function DebugPanel({ debug, onClose }) {
  if (!debug) return null;
  const unmapped = debug.mappedHeaders.filter(h => !h.ok && h.raw !== "");
  const mapped   = debug.mappedHeaders.filter(h => h.ok);
  return (
    <div style={{
      background: "#1a1a2e", color: "#e0e0e0", borderRadius: 12,
      padding: "16px 20px", marginBottom: 16, fontSize: 12,
    }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
        <span style={{ fontWeight: 600, color: "#fff" }}>
          Column detection — header found on row {debug.headerRow + 1}
        </span>
        <button onClick={onClose} style={{ background: "none", border: "none", color: "#aaa", cursor: "pointer", fontSize: 14 }}>✕</button>
      </div>
      <div style={{ display: "flex", gap: 24, flexWrap: "wrap" }}>
        <div>
          <div style={{ color: "#27a06b", fontWeight: 600, marginBottom: 6 }}>✓ Mapped ({mapped.length})</div>
          {mapped.map((h, i) => (
            <div key={i} style={{ color: "#aaa", marginBottom: 3 }}>
              <span style={{ color: "#fff" }}>{h.raw}</span> → <span style={{ color: "#7ec8e3" }}>{h.mapped}</span>
            </div>
          ))}
        </div>
        {unmapped.length > 0 && (
          <div>
            <div style={{ color: "#c0392b", fontWeight: 600, marginBottom: 6 }}>✕ Unmapped ({unmapped.length})</div>
            {unmapped.map((h, i) => (
              <div key={i} style={{ color: "#e07b7b", marginBottom: 3 }}>{h.raw}</div>
            ))}
            <div style={{ color: "#888", marginTop: 8, fontSize: 11 }}>
              Unmapped columns are ignored. If critical columns appear here, add them to COL_MAP.
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

/* ─── Upload Zone ─────────────────────────────────────────────────────── */
function UploadZone({ onData, fileName }) {
  const [dragging, setDragging] = useState(false);
  const [parsing, setParsing]   = useState(false);
  const [err, setErr]           = useState(null);
  const inputRef = useRef();

  const handle = useCallback(async (file) => {
    if (!file) return;
    const ext = file.name.split(".").pop().toLowerCase();
    if (!["xlsx", "xls", "csv"].includes(ext)) {
      setErr("Please upload an .xlsx, .xls, or .csv file.");
      return;
    }
    setErr(null);
    setParsing(true);
    try {
      const result = await parseExcel(file);
      onData(result.data, file.name, result.debug);
    } catch (e) {
      setErr("Could not parse file: " + e.message);
    } finally {
      setParsing(false);
    }
  }, [onData]);

  return (
    <div
      onDragOver={e => { e.preventDefault(); setDragging(true); }}
      onDragLeave={() => setDragging(false)}
      onDrop={e => { e.preventDefault(); setDragging(false); handle(e.dataTransfer.files[0]); }}
      onClick={() => inputRef.current.click()}
      style={{
        border: `2px dashed ${dragging ? "#2471b8" : "#cdd5e0"}`,
        borderRadius: 14, padding: "40px 24px", textAlign: "center",
        cursor: "pointer", background: dragging ? "#f0f6ff" : "#fafbfc",
        transition: "all 0.2s", userSelect: "none",
      }}
    >
      <input ref={inputRef} type="file" accept=".xlsx,.xls,.csv"
        style={{ display: "none" }} onChange={e => handle(e.target.files[0])} />
      {parsing ? (
        <div style={{ color: "#2471b8", fontSize: 14, fontWeight: 500 }}>⏳ Parsing file…</div>
      ) : (
        <>
          <div style={{ fontSize: 40, marginBottom: 12 }}>📊</div>
          <div style={{ fontSize: 15, fontWeight: 600, color: "#333", marginBottom: 6 }}>
            {fileName ? `Loaded: ${fileName}` : "Upload your medical tracker Excel"}
          </div>
          <div style={{ fontSize: 12, color: "#999" }}>
            Drag & drop or click — supports .xlsx · .xls · .csv
          </div>
          {err && <div style={{ color: "#c0392b", fontSize: 12, marginTop: 10 }}>{err}</div>}
        </>
      )}
    </div>
  );
}

/* ─── Main Dashboard ─────────────────────────────────────────────────── */
export default function MedicalTracker() {
  const [allData, setAllData]           = useState([]);
  const [fileName, setFileName]         = useState("");
  const [debugInfo, setDebugInfo]       = useState(null);
  const [showDebug, setShowDebug]       = useState(false);
  const [search, setSearch]             = useState("");
  const [zoneFilter, setZoneFilter]     = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [agingFilter, setAgingFilter]   = useState("all");
  const [sortCol, setSortCol]           = useState("aging");
  const [sortDir, setSortDir]           = useState("desc");
  const [page, setPage]                 = useState(1);
  const PAGE_SIZE = 15;

  const onData = useCallback((rows, name, debug) => {
    setAllData(rows);
    setFileName(name);
    setDebugInfo(debug);
    setShowDebug(true);
    setPage(1);
    setSearch("");
    setZoneFilter("all");
    setStatusFilter("all");
    setAgingFilter("all");
  }, []);

  const handleFileChange = async (file) => {
    if (!file) return;
    try {
      const result = await parseExcel(file);
      onData(result.data, file.name, result.debug);
    } catch (e) {
      console.error(e);
    }
  };

  const zones    = useMemo(() => ["all", ...new Set(allData.map(r => r.zone).filter(Boolean))], [allData]);
  const statuses = useMemo(() => ["all", ...new Set(allData.map(r => r.finalStatus).filter(Boolean))], [allData]);

  const filtered = useMemo(() => {
    return allData.filter(r => {
      if (zoneFilter !== "all" && r.zone !== zoneFilter) return false;
      if (statusFilter !== "all" && r.finalStatus !== statusFilter) return false;
      if (agingFilter === "critical" && r.aging < 60) return false;
      if (agingFilter === "high" && (r.aging < 30 || r.aging >= 60)) return false;
      if (agingFilter === "normal" && r.aging >= 30) return false;
      if (search) {
        const q = search.toLowerCase();
        return (
          String(r.nameOfLifeAssured).toLowerCase().includes(q) ||
          String(r.loanNumber).toLowerCase().includes(q) ||
          String(r.tpaApplicationNo).toLowerCase().includes(q) ||
          String(r.branch).toLowerCase().includes(q) ||
          String(r.state).toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [allData, zoneFilter, statusFilter, agingFilter, search]);

  const sorted = useMemo(() => {
    return [...filtered].sort((a, b) => {
      let av = a[sortCol], bv = b[sortCol];
      if (typeof av === "string") { av = av.toLowerCase(); bv = (bv || "").toLowerCase(); }
      if (av == null) return 1;
      if (bv == null) return -1;
      return sortDir === "asc" ? (av > bv ? 1 : -1) : (av < bv ? 1 : -1);
    });
  }, [filtered, sortCol, sortDir]);

  const pageCount = Math.max(1, Math.ceil(sorted.length / PAGE_SIZE));
  const pageRows  = sorted.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  const handleSort = (col) => {
    if (sortCol === col) setSortDir(d => d === "asc" ? "desc" : "asc");
    else { setSortCol(col); setSortDir("desc"); }
    setPage(1);
  };

  /* Chart data */
  const statusData = useMemo(() => {
    const c = {};
    filtered.forEach(r => { if (r.finalStatus) c[r.finalStatus] = (c[r.finalStatus] || 0) + 1; });
    return Object.entries(c).map(([name, value]) => ({ name, value }));
  }, [filtered]);

  const dispData = useMemo(() => {
    const c = {};
    filtered.forEach(r => { if (r.disposition) c[r.disposition] = (c[r.disposition] || 0) + 1; });
    return Object.entries(c).sort((a, b) => b[1] - a[1])
      .map(([name, value]) => ({ name: name.length > 16 ? name.slice(0, 16) + "…" : name, fullName: name, value }));
  }, [filtered]);

  const agingData = useMemo(() => {
    const b = { "<15d": 0, "15-29d": 0, "30-59d": 0, "60-89d": 0, "90+d": 0 };
    filtered.forEach(r => {
      const a = r.aging;
      if (a < 15) b["<15d"]++;
      else if (a < 30) b["15-29d"]++;
      else if (a < 60) b["30-59d"]++;
      else if (a < 90) b["60-89d"]++;
      else b["90+d"]++;
    });
    return Object.entries(b).map(([name, value], i) => ({ name, value, fill: AGING_COLORS[i] }));
  }, [filtered]);

  const branchData = useMemo(() => {
    const b = {};
    filtered.forEach(r => {
      if (!r.branch) return;
      if (!b[r.branch]) b[r.branch] = { total: 0, completed: 0 };
      b[r.branch].total++;
      if (r.finalStatus === "completed") b[r.branch].completed++;
    });
    return Object.entries(b).sort((a, b) => b[1].total - a[1].total).slice(0, 10)
      .map(([name, d]) => ({
        name: name.length > 14 ? name.slice(0, 14) + "…" : name,
        fullName: name, total: d.total,
        rate: Math.round((d.completed / d.total) * 100),
      }));
  }, [filtered]);

  const metrics = useMemo(() => {
    const total     = filtered.length;
    const completed = filtered.filter(r => r.finalStatus === "completed").length;
    const nc        = filtered.filter(r => r.finalStatus === "non contactable").length;
    const critical  = filtered.filter(r => r.aging >= 60).length;
    const pending   = filtered.filter(r => r.finalStatus === "pending").length;
    const avgPrem   = total ? Math.round(filtered.reduce((s, r) => s + (r.premium || 0), 0) / total) : 0;
    const compRate  = total ? Math.round((completed / total) * 100) : 0;
    return { total, completed, nc, critical, pending, avgPrem, compRate };
  }, [filtered]);

  const Th = ({ col, label, width }) => (
    <th onClick={() => handleSort(col)} style={{
      padding: "8px 12px", textAlign: "left", fontSize: 11, fontWeight: 600,
      color: "#666", whiteSpace: "nowrap", background: "#f7f8fa",
      borderBottom: "1px solid #eee", cursor: "pointer", width,
      userSelect: "none", position: "sticky", top: 0, zIndex: 1,
    }}>
      {label}{sortCol === col ? (sortDir === "asc" ? " ↑" : " ↓") : ""}
    </th>
  );

  const isEmpty = allData.length === 0;

  return (
    <div style={{
      fontFamily: "'DM Sans', 'Segoe UI', sans-serif",
      background: "#f4f5f7", minHeight: "100vh",
      padding: "24px 28px", color: "#1a1a2e",
    }}>

      {/* Header */}
      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", flexWrap: "wrap", gap: 12, marginBottom: 20 }}>
        <div>
          <h1 style={{ fontSize: 22, fontWeight: 700, margin: 0, letterSpacing: "-0.02em" }}>Medical Checkup Tracker</h1>
          <p style={{ fontSize: 13, color: "#888", margin: "4px 0 0" }}>Home Loan Insurance · Sales Team Monitoring</p>
        </div>
        {!isEmpty && (
          <div style={{ display: "flex", gap: 8 }}>
            <button onClick={() => setShowDebug(v => !v)} style={{
              padding: "8px 14px", borderRadius: 8, cursor: "pointer",
              background: "#fff", border: "1px solid #ddd", fontSize: 12,
              color: "#555", fontWeight: 500,
            }}>
              {showDebug ? "Hide" : "Show"} column map
            </button>
            <label style={{
              display: "inline-flex", alignItems: "center", gap: 7,
              padding: "8px 16px", borderRadius: 8, cursor: "pointer",
              background: "#fff", border: "1px solid #ddd", fontSize: 13,
              fontWeight: 500, color: "#333",
            }}>
              📂 Upload new file
              <input type="file" accept=".xlsx,.xls,.csv" style={{ display: "none" }}
                onChange={e => { handleFileChange(e.target.files[0]); e.target.value = ""; }} />
            </label>
          </div>
        )}
      </div>

      {/* Upload zone (empty state) */}
      {isEmpty ? (
        <div style={{ maxWidth: 560, margin: "60px auto" }}>
          <UploadZone onData={onData} fileName={fileName} />
          <p style={{ textAlign: "center", fontSize: 12, color: "#bbb", marginTop: 16 }}>
            Parsed entirely in the browser — data never leaves your device.
          </p>
        </div>
      ) : (
        <>
          {/* File info bar */}
          <div style={{ fontSize: 12, color: "#888", marginBottom: 12, display: "flex", alignItems: "center", gap: 8 }}>
            <span style={{ color: "#27a06b", fontWeight: 600 }}>✓</span>
            {fileName} — <strong style={{ color: "#555" }}>{allData.length.toLocaleString()} records loaded</strong>
          </div>

          {/* Debug panel */}
          {showDebug && debugInfo && (
            <DebugPanel debug={debugInfo} onClose={() => setShowDebug(false)} />
          )}

          {/* Filters */}
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 20 }}>
            {[
              { id: "zone",   label: "Zone",   val: zoneFilter,   opts: zones,    set: v => { setZoneFilter(v);   setPage(1); } },
              { id: "status", label: "Status", val: statusFilter,  opts: statuses, set: v => { setStatusFilter(v); setPage(1); } },
              {
                id: "aging", label: "Aging", val: agingFilter,
                opts: [
                  { value: "all",      label: "All Aging" },
                  { value: "critical", label: "Critical (60+ days)" },
                  { value: "high",     label: "High (30–59 days)" },
                  { value: "normal",   label: "Normal (<30 days)" },
                ],
                set: v => { setAgingFilter(v); setPage(1); },
              },
            ].map(f => (
              <select key={f.id} value={f.val} onChange={e => f.set(e.target.value)}
                style={{ fontSize: 12, padding: "6px 10px", borderRadius: 8, border: "1px solid #ddd", background: "#fff", color: "#333", cursor: "pointer" }}>
                {f.opts.map(o =>
                  typeof o === "string"
                    ? <option key={o} value={o}>{o === "all" ? `All ${f.label}s` : o}</option>
                    : <option key={o.value} value={o.value}>{o.label}</option>
                )}
              </select>
            ))}
          </div>

          {/* Metric Cards */}
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(140px, 1fr))", gap: 10, marginBottom: 20 }}>
            <MetricCard label="Total Cases"     value={metrics.total}        sub="active pipeline" />
            <MetricCard label="Completed"       value={metrics.completed}    sub={`${metrics.compRate}% rate`}  color="#27a06b" />
            <MetricCard label="Non Contactable" value={metrics.nc}           sub="needs follow-up"              color="#c0392b" />
            <MetricCard label="Critical Aging"  value={metrics.critical}     sub="60+ days pending"             color="#c0392b" />
            <MetricCard label="Pending"         value={metrics.pending}      sub="appointment awaited"          color="#d4870f" />
            <MetricCard label="Avg Premium"     value={fmt(metrics.avgPrem)} sub="per policy" />
          </div>

          {/* Charts Row 1 */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 14 }}>
            <Card title="Final status distribution">
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie data={statusData} cx="50%" cy="50%" innerRadius={52} outerRadius={78} paddingAngle={3} dataKey="value">
                    {statusData.map((e, i) => (
                      <Cell key={i} fill={STATUS_COLOR[e.name]?.dot || DISP_COLORS[i % DISP_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip content={<ChartTip />} />
                  <Legend iconSize={9} iconType="square" formatter={v => <span style={{ fontSize: 11, color: "#555" }}>{v}</span>} />
                </PieChart>
              </ResponsiveContainer>
            </Card>

            <Card title="Sales disposition breakdown">
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={dispData} margin={{ top: 0, right: 8, left: -20, bottom: 0 }}>
                  <XAxis dataKey="name" tick={{ fontSize: 10 }} interval={0} angle={-12} textAnchor="end" height={38} />
                  <YAxis tick={{ fontSize: 10 }} allowDecimals={false} />
                  <Tooltip content={<ChartTip />} />
                  <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                    {dispData.map((_, i) => <Cell key={i} fill={DISP_COLORS[i % DISP_COLORS.length]} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </Card>
          </div>

          {/* Charts Row 2 */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 14 }}>
            <Card title="Aging bucket analysis">
              <ResponsiveContainer width="100%" height={180}>
                <BarChart data={agingData} margin={{ top: 0, right: 8, left: -20, bottom: 0 }}>
                  <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 10 }} allowDecimals={false} />
                  <Tooltip content={<ChartTip />} />
                  <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                    {agingData.map((e, i) => <Cell key={i} fill={e.fill} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </Card>

            <Card title="Branch completion rate (top 10)">
              <div style={{ maxHeight: 200, overflowY: "auto" }}>
                {branchData.length === 0
                  ? <div style={{ color: "#bbb", fontSize: 13 }}>No branch data</div>
                  : branchData.map((b, i) => (
                    <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, padding: "6px 0", borderBottom: "1px solid #f0f0f0", fontSize: 12 }}>
                      <span style={{ flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }} title={b.fullName}>{b.name}</span>
                      <span style={{ color: "#aaa", minWidth: 22, textAlign: "right" }}>{b.total}</span>
                      <div style={{ width: 80, background: "#eee", borderRadius: 4, height: 6, overflow: "hidden" }}>
                        <div style={{ width: `${b.rate}%`, height: 6, borderRadius: 4, background: agingColor(100 - b.rate) }} />
                      </div>
                      <span style={{ minWidth: 34, textAlign: "right", fontWeight: 700, color: agingColor(100 - b.rate) }}>{b.rate}%</span>
                    </div>
                  ))
                }
              </div>
            </Card>
          </div>

          {/* Customer Table */}
          <Card>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14, flexWrap: "wrap", gap: 8 }}>
              <span style={{ fontSize: 13, fontWeight: 600, color: "#555" }}>Customer records</span>
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <input
                  type="text" placeholder="Search name / loan / branch / state…"
                  value={search} onChange={e => { setSearch(e.target.value); setPage(1); }}
                  style={{ fontSize: 12, padding: "6px 12px", borderRadius: 8, border: "1px solid #ddd", width: 240, outline: "none" }}
                />
                <span style={{ fontSize: 11, color: "#aaa", whiteSpace: "nowrap" }}>{sorted.length.toLocaleString()} records</span>
              </div>
            </div>

            <div style={{ overflowX: "auto" }}>
              <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
                <thead>
                  <tr>
                    <Th col="tpaApplicationNo"  label="TPA App No."  width={110} />
                    <Th col="loanNumber"         label="Loan No."     width={100} />
                    <Th col="nameOfLifeAssured"  label="Name"         width={140} />
                    <Th col="age"                label="Age"          width={50}  />
                    <Th col="gender"             label="Gender"       width={70}  />
                    <Th col="medicalType"        label="Med. Type"    width={80}  />
                    <Th col="premium"            label="Premium"      width={80}  />
                    <Th col="tpaName"            label="TPA"          width={90}  />
                    <Th col="substatus"          label="Substatus"    width={140} />
                    <Th col="finalStatus"        label="Final Status" width={120} />
                    <Th col="aging"              label="Aging"        width={62}  />
                    <Th col="appointmentDate"    label="Appt. Date"   width={90}  />
                    <Th col="disposition"        label="Disposition"  width={130} />
                    <Th col="branch"             label="Branch"       width={110} />
                    <Th col="zone"               label="Zone"         width={70}  />
                    <Th col="state"              label="State"        width={90}  />
                  </tr>
                </thead>
                <tbody>
                  {pageRows.length === 0 ? (
                    <tr>
                      <td colSpan={16} style={{ textAlign: "center", padding: "40px", color: "#ccc" }}>
                        No records match the current filters.
                      </td>
                    </tr>
                  ) : pageRows.map((r, i) => (
                    <tr key={i} style={{ borderBottom: "1px solid #f5f5f5" }}
                      onMouseEnter={e => e.currentTarget.style.background = "#fafafa"}
                      onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
                      <td style={{ padding: "8px 12px", color: "#555" }}>{String(r.tpaApplicationNo || "").slice(-14)}</td>
                      <td style={{ padding: "8px 12px", color: "#555" }}>{String(r.loanNumber || "").slice(-14)}</td>
                      <td style={{ padding: "8px 12px", fontWeight: 500 }} title={r.nameOfLifeAssured}>{r.nameOfLifeAssured}</td>
                      <td style={{ padding: "8px 12px" }}>{r.age}</td>
                      <td style={{ padding: "8px 12px", textTransform: "capitalize" }}>{r.gender}</td>
                      <td style={{ padding: "8px 12px", textTransform: "capitalize" }}>{r.medicalType}</td>
                      <td style={{ padding: "8px 12px" }}>{fmt(r.premium)}</td>
                      <td style={{ padding: "8px 12px", color: "#555" }}>{r.tpaName}</td>
                      <td style={{ padding: "8px 12px", color: "#777", maxWidth: 140, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }} title={r.substatus}>{r.substatus}</td>
                      <td style={{ padding: "8px 12px" }}><Badge value={r.finalStatus} /></td>
                      <td style={{ padding: "8px 12px", fontWeight: 700, color: agingColor(r.aging) }}>{r.aging || 0}d</td>
                      <td style={{ padding: "8px 12px", color: "#555" }}>{r.appointmentDate || "—"}</td>
                      <td style={{ padding: "8px 12px", maxWidth: 130, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }} title={r.disposition}>{r.disposition}</td>
                      <td style={{ padding: "8px 12px", color: "#555" }}>{r.branch}</td>
                      <td style={{ padding: "8px 12px" }}>{r.zone}</td>
                      <td style={{ padding: "8px 12px", color: "#777" }}>{r.state}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Pagination */}
            {pageCount > 1 && (
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: 16, flexWrap: "wrap", gap: 8 }}>
                <span style={{ fontSize: 12, color: "#aaa" }}>
                  Showing {((page - 1) * PAGE_SIZE) + 1}–{Math.min(page * PAGE_SIZE, sorted.length)} of {sorted.length.toLocaleString()}
                </span>
                <div style={{ display: "flex", gap: 6 }}>
                  {[
                    { label: "««",     action: () => setPage(1),                          disabled: page === 1 },
                    { label: "← Prev", action: () => setPage(p => Math.max(1, p - 1)),    disabled: page === 1 },
                    { label: `${page} / ${pageCount}`, action: null, disabled: true, plain: true },
                    { label: "Next →", action: () => setPage(p => Math.min(pageCount, p + 1)), disabled: page === pageCount },
                    { label: "»»",     action: () => setPage(pageCount),                  disabled: page === pageCount },
                  ].map((btn, i) => (
                    btn.plain
                      ? <span key={i} style={{ padding: "5px 12px", fontSize: 12, color: "#555" }}>{btn.label}</span>
                      : <button key={i} onClick={btn.action} disabled={btn.disabled}
                          style={{ padding: "5px 12px", borderRadius: 6, border: "1px solid #ddd", background: "#fff", fontSize: 12, cursor: btn.disabled ? "not-allowed" : "pointer", color: btn.disabled ? "#ccc" : "#333" }}>
                          {btn.label}
                        </button>
                  ))}
                </div>
              </div>
            )}
          </Card>
        </>
      )}
    </div>
  );
}